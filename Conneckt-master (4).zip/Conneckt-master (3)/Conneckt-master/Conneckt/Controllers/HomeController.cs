﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Conneckt.Models;
using System.Net.Http;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Text;

namespace Conneckt.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Activate(Phone phone)
        {
            return View();
        }

        public async Task<ActionResult> GetPhoneNumber()
        {
            var Tracfone = new Tracfone();

            //these 2 lines will be changed to come from browser...
            string accessToken =
                "Basic N2MyMTE5ZmYtZjcwYi00MDQ1LThhZTgtNzIxYmFhYzc1NTdlOmVWM2ZLM3hJN2xSNmxDMGpFMmtGNGdYNHZFM2lDMWNNOHNHMHdYMW9IMHRFMmhGMGVF";
            string addData =
                "{\r\n  \"relatedParties\": [\r\n    {\r\n      \"party\": {\r\n        \"partyID\": \"Approved Link\",\r\n        \"languageAbility\": \"ENG\",\r\n        \"partyExtension\": [\r\n          {\r\n            \"name\": \"vendorName\",\r\n            \"value\": \"Approved Link\"\r\n          },\r\n          {\r\n            \"name\": \"vendorStore\",\r\n            \"value\": \"1231234234424\"\r\n          },\r\n          {\r\n            \"name\": \"vendorTerminal\",\r\n            \"value\": \"1231234234424\"\r\n          },\r\n          {\r\n            \"name\": \"sourceSystem\",\r\n            \"value\": \"EBP\"\r\n          },\r\n          {\r\n            \"name\": \"accountEmail\",\r\n            \"value\": \"\"\r\n          },\r\n          {\r\n            \"name\": \"partyTransactionID\",\r\n            \"value\": \"indirect_1231234234424\"\r\n          }\r\n        ]\r\n      },\r\n      \"roleType\": \"PARTNER\"\r\n    }\r\n  ],\r\n  \"customerAccounts\": [\r\n    {\r\n      \"action\": \"ADD_DEVICE\",\r\n      \"customerProducts\": [\r\n        {\r\n          \"product\": {\r\n            \"productSerialNumber\": \"100000002884194\",\r\n            \"productStatus\": \"ACTIVE\",\r\n            \"accountId\": \"594463672\",\r\n            \"productCategory\": \"HANDSET\",\r\n            \"productSpecification\": {\r\n              \"brand\": \"CLEARWAY\"\r\n            }\r\n          }\r\n        }\r\n      ]\r\n    }\r\n  ]\r\n}";
            string activateData =
                "{\"orderDate\":\"2016-04-16T16:42:23-04:00\",\"relatedParties\":[{\"roleType\":\"partner\",\"party\":{\"partyExtension\":[{\"name\":\"partyTransactionID\",\"value\":\"84306270-c4cd-4142-b41a-311b63b70074\"},{\"name\":\"sourceSystem\",\"value\":\"EBP\"}],\"partyID\":\"vendor name\",\"languageAbility\":\"Approved Link\"}},{\"roleType\":\"customer\",\"party\":{\"individual\":{\"id\":\"\"},\"partyExtension\":[{\"name\":\"accountEmail\",\"value\":\"\"}]}}],\"externalID\":\"123\",\"orderItems\":[{\"product\":{\"subCategory\":\"BRANDED\",\"productCategory\":\"HANDSET\",\"productSpecification\":{\"brand\":\"CLEARWAY\"},\"relatedServices\":[{\"id\":\"\",\"category\":\"SERVICE_PLAN\"}],\"productSerialNumber\":\"100000002445129\",\"supportingResources\":[{\"serialNumber\":\"8901260710022269757\",\"resourceType\":\"SIM_CARD\"}]},\"id\":\"1\",\"location\":{\"postalAddress\":{\"zipcode\":\"31088\"}},\"action\":\"ACTIVATION\"}]}";

            dynamic bearerAuthorization = await Tracfone.GetBearerAuthorization(accessToken);
            string added = await Tracfone.AddDevice(bearerAuthorization, addData);
            var result = Tracfone.ActivateDevice(bearerAuthorization, activateData, added);

            // this is not the way to test it since i cant test what Task returns, it's an example
            if (result.Status.ToString() != "waiting for activation")
            {
                //phoneNumberOrSomethingElseIDK
                return Json(result.Result);
            }
            return Json("Wait a damn minute 123");
        }
    }
}
