﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Conneckt.Controllers
{
    public class Tracfone
    {
        public async Task<dynamic> GetBearerAuthorization(string accessToken)
        {
            var client = new HttpClient();
            client.DefaultRequestHeaders.Add("Authorization", accessToken);
            //var url = "https://apigateway.tracfone.com/api/order-mgmt/oauth/token?grant_type=client_credentials&scope=/order-mgmt";
            var url = "https://jsonplaceholder.typicode.com/posts/1";
            HttpResponseMessage response = await client.GetAsync(url);
            if (response.IsSuccessStatusCode)
            {
                var responseData = response.Content.ReadAsStringAsync().Result;
                return JObject.Parse(responseData);
            }
            return "Error";
        }

        public async Task<string> AddDevice(dynamic bearerAuthorization, string data)
        {
            var client = new HttpClient();
            // var sendingData = new StringContent(data, Encoding.UTF8, "application/json");
            // client.DefaultRequestHeaders.Add("Authorization", $"{barerAuthorization.type} {barerAuthorization.token}");
            // var url = "https://apigateway.tracfone.com/api/customer-mgmt/addDeviceToAccount?client_id=2d3d3fc0-3bc1-44c0-9cf5-600e1a7b02d5";

            var id = bearerAuthorization.userId;
            var url = "https://jsonplaceholder.typicode.com/posts/" + id + "/comments";
            HttpResponseMessage response = await client.GetAsync(url);
            if (response.IsSuccessStatusCode)
            {
                var responseContent = response.Content.ReadAsStringAsync().Result;
                return responseContent;
            }
            return "Error";
        }

        public async Task<string> ActivateDevice(dynamic bearerAuthorization, string data, dynamic added)
        {
            var client = new HttpClient();
            // var sendingData = new StringContent(data, Encoding.UTF8, "application/json");
            // client.DefaultRequestHeaders.Add("Authorization", $"{barerAuthorization.type} {barerAuthorization.token}");
            // var url = "https://apigateway.tracfone.com/api/order-mgmt/v1/serviceorder?client_id=2d3d3fc0-3bc1-44c0-9cf5-600e1a7b02d5";
            // HttpResponseMessage response = await client.PostAsync(url, sendingData);

            var id = bearerAuthorization.userId;
            var url = "https://jsonplaceholder.typicode.com/posts/" + id + "/comments";
            HttpResponseMessage response = await client.GetAsync(url);
            if(response.IsSuccessStatusCode)
            {
                var responseContent = response.Content.ReadAsStringAsync().Result;
                return responseContent;
            }
            return "Error";
        }
    }
}
