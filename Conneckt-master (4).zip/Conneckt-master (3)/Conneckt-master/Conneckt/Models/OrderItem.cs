﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Conneckt.Models
{
    public class OrderItem
    {
        public Product Product { get; set; }
        public int ID { get; set; }
        public Location Location { get; set; }
        public string Action { get; set; }
    }
}
