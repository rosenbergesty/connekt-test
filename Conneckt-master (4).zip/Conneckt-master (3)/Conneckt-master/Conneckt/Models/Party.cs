﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Conneckt.Models
{
    public class Party
    {
        //maybe class
        public Dictionary<string, string> PartyExtension { get; set; }
        public string PartyID { get; set; }
        public string LanguageAbilit { get; set; }
        public Individual Individual { get; set; }
    }
}
