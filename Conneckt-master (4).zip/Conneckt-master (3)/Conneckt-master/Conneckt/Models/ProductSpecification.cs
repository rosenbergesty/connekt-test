﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Conneckt.Models
{
    public class ProductSpecification
    {
        public string Brand { get; set; }
    }
}
