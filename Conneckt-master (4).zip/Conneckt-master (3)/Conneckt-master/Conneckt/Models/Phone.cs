﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Conneckt.Models
{
    public class Phone
    {
        //maybe string
        public DateTime OrderDate { get; set; }
        public IEnumerable<RelatedParty> RlatedParties { get; set; }
        //maybe string
        public int ExternalID { get; set; }
        public IEnumerable<OrderItem> OrderItems { get; set; }

        //public int Sim { get; set; }
        //public string Serial { get; set; }
        //public int Zip { get; set; }
    }
}
