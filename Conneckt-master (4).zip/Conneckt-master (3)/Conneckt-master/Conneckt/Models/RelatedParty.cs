﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Conneckt.Models
{
    public class RelatedParty
    {
        //maybe enum
        public string RoleType { get; set; }
        public Party Party { get; set; }
    }
}
