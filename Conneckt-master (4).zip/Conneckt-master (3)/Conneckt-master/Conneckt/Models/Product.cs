﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Conneckt.Models
{
    public class Product
    {
        public string SubCategory { get; set; }
        public string ProductCategory { get; set; }
        public ProductSpecification ProductSpecification { get; set; }
        public IEnumerable<RelatedService> RelatedServices { get; set; }
        public long ProductSerialNumber { get; set; }
        public IEnumerable<SupportingResource> SupportingResources { get; set; }
    }
}
