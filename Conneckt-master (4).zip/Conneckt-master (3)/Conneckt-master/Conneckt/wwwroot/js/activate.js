﻿$(() => {
    setInterval(() => {
        $.getJSON("/home/GetPhoneNumber", (data) => {
            $("#line").text(data);
        });
    }, 1000)
})